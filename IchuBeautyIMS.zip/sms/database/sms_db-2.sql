-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 06:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `back_order_list`
--

CREATE TABLE `back_order_list` (
  `id` int(30) NOT NULL,
  `receiving_id` int(30) NOT NULL,
  `po_id` int(30) NOT NULL,
  `bo_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = partially received, 2 =received',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `back_order_list`
--

INSERT INTO `back_order_list` (`id`, `receiving_id`, `po_id`, `bo_code`, `supplier_id`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `remarks`, `status`, `date_created`, `date_updated`) VALUES
(1, 1, 1, 'BO-0001', 1, 40740, 3, 1125, 12, 4365, NULL, 1, '2021-11-03 11:20:38', '2021-11-03 11:20:51');

-- --------------------------------------------------------

--
-- Table structure for table `bo_items`
--

CREATE TABLE `bo_items` (
  `bo_id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL,
  `total` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bo_items`
--

INSERT INTO `bo_items` (`bo_id`, `item_id`, `quantity`, `price`, `unit`, `total`) VALUES
(1, 1, 250, 150, 'pcs', 37500);

-- --------------------------------------------------------

--
-- Table structure for table `item_list`
--

CREATE TABLE `item_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `item_list`
--

INSERT INTO `item_list` (`id`, `name`, `description`, `supplier_id`, `cost`, `status`, `date_created`, `date_updated`) VALUES
(1, 'BR-R301 BREMOD HAIR COLOR 100ML-0.00 DUST', '6941181105150', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(2, 'BR-R301 BREMOD HAIR COLOR 100ML-0.19 ASH', '6941181106645', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(3, 'BR-R301 BREMOD HAIR COLOR 100ML-0.22 VIOLET', '6941181106201', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(4, 'BR-R301 BREMOD HAIR COLOR 100ML-0.33 YELLOW', '6941181106218', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(5, 'BR-R301 BREMOD HAIR COLOR 100ML-0.44 ORANGE', '6941181106225', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(6, 'BR-R301 BREMOD HAIR COLOR 100ML-0.45 RED', '6941181106775', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(7, 'BR-R301 BREMOD HAIR COLOR 100ML-0.77 GREEN', '6941181106690', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(8, 'BR-R301 BREMOD HAIR COLOR 100ML-0.88 BLUE', '6941181106386', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(9, 'BR-R301 BREMOD HAIR COLOR 100ML-10.0 LIGHTEST BLOND', '6941181106553', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(10, 'BR-R301 BREMOD HAIR COLOR 100ML-10.01 SILVER GRAY', '6941181105907', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(11, 'BR-R301 BREMOD HAIR COLOR 100ML-10.11 VERY LIGHT INTENSE ASH BLOND', '6941181117955', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(12, 'BR-R301 BREMOD HAIR COLOR 100ML-10.13 ASH BLOND', '6941181117979', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(13, 'BR-R301 BREMOD HAIR COLOR 100ML-10.45 VERY LIGHT ASH PINK', '6941181117986', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(14, 'BR-R301 BREMOD HAIR COLOR 100ML-10.61 LILAC PURPLE', '6941181117931', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(15, 'BR-R301 BREMOD HAIR COLOR 100ML-12.22 VERY STUFFY GREEN BLONDE', '6941181106782', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(16, 'BR-R301 BREMOD HAIR COLOR 100ML-12.45 VERY RED BLONDE', '6941181106805', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(17, 'BR-R301 BREMOD HAIR COLOR 100ML-12.66 VERY VIOLET BLONDE', '6941181106812', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(18, 'BR-R301 BREMOD HAIR COLOR 100ML-12.88 VERY ASH GOLDEN BLONDE', '6941181106799', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(19, 'BR-R301 BREMOD HAIR COLOR 100ML-2.0 BLACK', '6941181106560', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(20, 'BR-R301 BREMOD HAIR COLOR 100ML-3.0 DARK BROWN', '6941181106577', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(21, 'BR-R301 BREMOD HAIR COLOR 100ML-4.0 MEDIUM BROWN', '6941181106584', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(22, 'BR-R301 BREMOD HAIR COLOR 100ML-44.77 CHESNUT', '6941181117924', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(23, 'BR-R301 BREMOD HAIR COLOR 100ML-4.5 RED CHESNUT', '6941181106751', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(24, 'BR-R301 BREMOD HAIR COLOR 100ML-5.0 LIGHT BROWN', '6941181106249', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(25, 'BR-R301 BREMOD HAIR COLOR 100ML-5.17 MOCHA BROWN', '6941181106911', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(26, 'BR-R301 BREMOD HAIR COLOR 100ML-5.4 DARK COPPER', '6941181106256', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(27, 'BR-R301 BREMOD HAIR COLOR 100ML-5.5 COCO', '6941181106263', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(28, 'BR-R301 BREMOD HAIR COLOR 100ML-5.56 MAHOGANY', '6941181106409', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(29, 'BR-R301 BREMOD HAIR COLOR 100ML-6.0 DARK BLOND', '6941181106591', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(30, 'BR-R301 BREMOD HAIR COLOR 100ML-6.1 DARK ASH BLOND', '6941181106416', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(31, 'BR-R301 BREMOD HAIR COLOR 100ML-6.17 HONEY TEA BROWN', '6941181106928', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(32, 'BR-R301 BREMOD HAIR COLOR 100ML-6.3 DARK GOLDEN BROWN', '6941181106423', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(33, 'BR-R301 BREMOD HAIR COLOR 100ML-6.31 GOLDEN ASH BLOND', '6941181106454', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(34, 'BR-R301 BREMOD HAIR COLOR 100ML-6.33 INTENSE DARK GOLDEN BROWN', '6941181106713', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(35, 'BR-R301 BREMOD HAIR COLOR 100ML-6.43 DARK COPPER BLOND', '6941181106461', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(36, 'BR-R301 BREMOD HAIR COLOR 100ML-6.5 COFFEE BROWN', '6941181106768', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(37, 'BR-R301 BREMOD HAIR COLOR 100ML-7.0 BLOND', '6941181106607', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(38, 'BR-R301 BREMOD HAIR COLOR 100ML-7.1 GRAY', '6941181106485', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(39, 'BR-R301 BREMOD HAIR COLOR 100ML-7.17 CHOCOLATE BROWN', '6941181105815', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(40, 'BR-R301 BREMOD HAIR COLOR 100ML-7.3 GOLDEN BROWN', '6941181106287', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(41, 'BR-R301 BREMOD HAIR COLOR 100ML-7.31 LIGHT GOLDEN ASH BLOND', '6941181106324', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(42, 'BR-R301 BREMOD HAIR COLOR 100ML-7.33 DARK GOLDEN', '6941181106720', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(43, 'BR-R301 BREMOD HAIR COLOR 100ML-7.37 GOLDEN FLAXEN', '6941181106331', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(44, 'BR-R301 BREMOD HAIR COLOR 100ML-7.4 LIGHT COPPER', '6941181106294', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(45, 'BR-R301 BREMOD HAIR COLOR 100ML-7.5 RED BROWN', '6941181106300', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(46, 'BR-R301 BREMOD HAIR COLOR 100ML-7.56 LIGHT MAHOGANY', '6941181106362', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(47, 'BR-R301 BREMOD HAIR COLOR 100ML-7.7 VELVET BLOND', '6941181106317', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(48, 'BR-R301 BREMOD HAIR COLOR 100ML-7.77 MOCHA CHOCOLATE', '6941181105365', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(49, 'BR-R301 BREMOD HAIR COLOR 100ML-77.71 NATURAL ASH', '6941181183912', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(50, 'BR-R301 BREMOD HAIR COLOR 100ML-8.0 LIGHT BLOND', '6941181106614', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(51, 'BR-R301 BREMOD HAIR COLOR 100ML-8.1 LIGHT GRAY', '6941181106492', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(52, 'BR-R301 BREMOD HAIR COLOR 100ML-8.10 ASH BROWN', '6941181118013', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(53, 'BR-R301 BREMOD HAIR COLOR 100ML-8.16 ASH GREY', '6941181118006', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(54, 'BR-R301 BREMOD HAIR COLOR 100ML-8.2 LIGHT STUFFY GREEN BLONDE', '6941181106683', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(55, 'BR-R301 BREMOD HAIR COLOR 100ML-8.3 LIGHT GLODEN BROWN', '6941181106379', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(56, 'BR-R301 BREMOD HAIR COLOR 100ML-8.33 BRIGHT GOLD', '6941181106737', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(57, 'BR-R301 BREMOD HAIR COLOR 100ML-8.43 LIGHT COPPER BLOND', '6941181106515', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(58, 'BR-R301 BREMOD HAIR COLOR 100ML-8.45 BURGUNDY', '6941181106522', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(59, 'BR-R301 BREMOD HAIR COLOR 100ML-8.65 PINK ORANGE', '6941181183905', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(60, 'BR-R301 BREMOD HAIR COLOR 100ML-8.67 PINK BROWN', '6941181183899', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(61, 'BR-R301 BREMOD HAIR COLOR 100ML-8.7 RICH VELVET BLOND', '6941181106508', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(62, 'BR-R301 BREMOD HAIR COLOR 100ML-8.77 MATCHA CHOCOLATE', '6941181105372', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(63, 'BR-R301 BREMOD HAIR COLOR 100ML-9.0 LIGHTER BLOND', '6941181106621', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(64, 'BR-R301 BREMOD HAIR COLOR 100ML-9.01 METALLIC GRAY', '6941181105839', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(65, 'BR-R301 BREMOD HAIR COLOR 100ML-9.1 VERY LIGHT ASH BLOND', '6941181106638', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(66, 'BR-R301 BREMOD HAIR COLOR 100ML-9.11 SMOKEY SILVER ASH', '6941181117962', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(67, 'BR-R301 BREMOD HAIR COLOR 100ML-9.16 DEEP PLATINUM LIGHT ASH', '6941181117993', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(68, 'BR-R301 BREMOD HAIR COLOR 100ML-9.18 GREY BLUE', '6941181117948', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(69, 'BR-R301 BREMOD HAIR COLOR 100ML-9.3 LIGHT GOLDEN BLONDE', '6941181106706', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(70, 'BR-R301 BREMOD HAIR COLOR 100ML-9.33 VERY LIGHT GOLDEN INTENSE BLONDE', '6941181106744', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(71, 'BR-R301 BREMOD HAIR COLOR 100ML-9.37 LIGHT GOLDEN FLAXEN', '6941181106546', 1, 36, 1, '2024-03-29 10:43:57', '2024-03-29 10:43:57'),
(72, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-0.00 DUST', '6941181182137', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(73, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-0.19 ASH', '6941181182212', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(74, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-0.88 BLUE', '6941181182304', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(75, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-2.0 BLACK', '6941181182120', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(76, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-3.0 DARK BROWN', '6941181182113', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(77, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-4.0 MEDIUM BROWN', '6941181182106', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(78, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-5.0 LIGHT BROWN', '6941181182090', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(79, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-6.0 DARK BLONDE', '6941181182083', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(80, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-6.17 DARK COLD BROWN', '6941181182410', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(81, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-6.27 GREEN BROWN', '6941181182496', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(82, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-6.71 HONEY TEA BROWN', '6941181182434', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(83, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-7.0 BLONDE', '6941181182076', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(84, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-7.11 DARK ASH', '6941181182205', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(85, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-7.17 COLD BROWN', '6941181182403', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(86, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-7.18 DARK SMOKEY BLUE', '6941181182298', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(87, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-7.77 MATCHA CHOCOLATE', '6941181182441', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(88, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.0 LIGHT BLONDE', '6941181182069', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(89, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.1 GRAY', '6941181182168', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(90, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.11 VERY LIGHT ASH', '6941181182199', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(91, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.13 ASH BLONDE', '6941181182243', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(92, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.15 ROSE BLONDE', '6941181182397', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(93, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.17 MILK TEA ASH', '6941181182274', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(94, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.21 AOKI ASH', '6941181182336', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(95, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.27 LIGHT GREEN BROWN', '6941181182489', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(96, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.43 LIGHT COPPER BLONDE', '6941181182472', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(97, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.61 PURPLE ASH', '6941181182373', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(98, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-8.71 LIGHT HONEY TEA BROWN', '6941181182427', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(99, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.0 LIGHTER BLOND', '6941181182052', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(100, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.1 LIGHT GRAY', '6941181182151', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(101, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.11 VERY LIGHT INTENSE ASH', '6941181182182', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(102, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.13 LIGHT ASH BLONDE', '6941181182236', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(103, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.16 SMOKEY ASH PURPLE', '6941181182366', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(104, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.17 LIGHT RICE ASH', '6941181182267', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(105, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.18 LIGHT SMOKEY BLUE', '6941181182281', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(106, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.3 LIGHT GOLDEN BLONDE', '6941181182458', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(107, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-9.37 LIGHT BLONDE BROWN', '6941181182465', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(108, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.0 LIGHTEST BLONDE', '6941181182045', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(109, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.1 VERY LIGHT GRAY', '6941181182144', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(110, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.11 ASH WHITE', '6941181182175', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(111, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.13 VERY LIGHT ASH BLOND', '6941181182229', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(112, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.17 VERY LIGHT RICE ASH', '6941181182250', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(113, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.21 VERY LIGHT AOKI ASH', '6941181182328', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(114, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.31 CHAMPAGNE BLOND', '6941181182311', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(115, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.61 LIGHT PURPLE ASH', '6941181182359', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(116, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-10.65 PINK', '6941181182380', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(117, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-D66.74 COCO BROWM', '6941181182021', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(118, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-D66.77 MOCHA BROWN', '6941181182014', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(119, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-G55.74 WARM BROWN', '6941181182007', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(120, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-G55.77 BROWN', '6941181181994', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27'),
(121, 'BR-R308 BREMOD COCOA BUTTER HAIR COLOR 100ML-X1 COORDINATION COLOR', '6941181182038', 1, 48, 1, '2024-03-29 10:49:27', '2024-03-29 10:49:27');

-- --------------------------------------------------------

--
-- Table structure for table `po_items`
--

CREATE TABLE `po_items` (
  `po_id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL,
  `total` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `po_items`
--

INSERT INTO `po_items` (`po_id`, `item_id`, `quantity`, `price`, `unit`, `total`) VALUES
(1, 1, 500, 150, 'pcs', 75000),
(4, 1, 2, 36, '', 72),
(9, 1, 23, 36, '', 828),
(10, 1, 6457, 36, '', 232452),
(11, 1, 2, 36, '', 72),
(12, 23, 2, 36, '', 72);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order_list`
--

CREATE TABLE `purchase_order_list` (
  `id` int(30) NOT NULL,
  `po_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = partially received, 2 =received',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase_order_list`
--

INSERT INTO `purchase_order_list` (`id`, `po_code`, `supplier_id`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `remarks`, `status`, `date_created`, `date_updated`) VALUES
(1, 'PO-0001', 1, 81480, 3, 2250, 12, 8730, 'Sample', 2, '2021-11-03 11:20:22', '2021-11-03 11:21:00'),
(4, 'PO-0002', 1, 0, 0, 0, 0, 0, '', 2, '2024-04-03 23:17:35', '2024-04-03 23:18:27'),
(9, 'PO-0003', 1, 0, 0, 0, 0, 0, '', 2, '2024-04-05 11:25:37', '2024-04-05 11:25:46'),
(10, 'PO-0004', 1, 0, 0, 0, 0, 0, '', 2, '2024-04-05 11:48:03', '2024-04-05 11:48:10'),
(11, 'PO-0005', 1, 0, 0, 0, 0, 0, '', 2, '2024-04-05 11:51:17', '2024-04-05 11:52:28'),
(12, 'PO-0006', 1, 0, 0, 0, 0, 0, '', 2, '2024-04-05 12:00:15', '2024-04-05 12:00:42');

-- --------------------------------------------------------

--
-- Table structure for table `receiving_list`
--

CREATE TABLE `receiving_list` (
  `id` int(30) NOT NULL,
  `form_id` int(30) NOT NULL,
  `from_order` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=PO ,2 = BO',
  `amount` float NOT NULL DEFAULT 0,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `stock_ids` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receiving_list`
--

INSERT INTO `receiving_list` (`id`, `form_id`, `from_order`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `stock_ids`, `remarks`, `date_created`, `date_updated`) VALUES
(1, 1, 1, 40740, 3, 1125, 12, 4365, '1', 'Sample', '2021-11-03 11:20:38', '2021-11-03 11:20:38'),
(9, 4, 1, 0, 0, 0, 0, 0, '30', '', '2024-04-03 23:18:27', '2024-04-03 23:18:27'),
(14, 9, 1, 0, 0, 0, 0, 0, '42', '', '2024-04-05 11:25:46', '2024-04-05 11:48:15'),
(15, 10, 1, 0, 0, 0, 0, 0, '41', '', '2024-04-05 11:48:10', '2024-04-05 11:48:10'),
(16, 11, 1, 0, 0, 0, 0, 0, '43', '', '2024-04-05 11:52:28', '2024-04-05 11:52:28'),
(17, 12, 1, 0, 0, 0, 0, 0, '44', '', '2024-04-05 12:00:42', '2024-04-05 12:00:42');

-- --------------------------------------------------------

--
-- Table structure for table `return_list`
--

CREATE TABLE `return_list` (
  `id` int(30) NOT NULL,
  `return_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `stock_ids` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_list`
--

CREATE TABLE `sales_list` (
  `id` int(30) NOT NULL,
  `sales_code` varchar(50) NOT NULL,
  `client` text DEFAULT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `stock_ids` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_list`
--

INSERT INTO `sales_list` (`id`, `sales_code`, `client`, `amount`, `remarks`, `stock_ids`, `date_created`, `date_updated`) VALUES
(2, 'SALE-0001', 'Guest', 108, '', '32,33', '2024-04-04 01:30:41', '2024-04-04 01:30:42'),
(3, 'SALE-0002', 'Guest', 36, '', '34', '2024-04-04 01:30:52', '2024-04-04 01:30:52');

-- --------------------------------------------------------

--
-- Table structure for table `stock_list`
--

CREATE TABLE `stock_list` (
  `id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `unit` varchar(250) DEFAULT NULL,
  `price` float NOT NULL DEFAULT 0,
  `total` float NOT NULL DEFAULT current_timestamp(),
  `type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=IN , 2=OUT',
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_list`
--

INSERT INTO `stock_list` (`id`, `item_id`, `quantity`, `unit`, `price`, `total`, `type`, `date_created`) VALUES
(1, 1, 250, 'pcs', 150, 37500, 1, '2021-11-03 11:20:38'),
(16, 2, 10, 'pcs', 200, 2000, 2, '2021-11-03 13:45:53'),
(17, 4, 5, 'boxes', 205, 1025, 2, '2021-11-03 13:45:53'),
(30, 1, 2, '', 36, 72, 1, '2024-04-03 23:18:27'),
(32, 1, 2, '', 36, 72, 2, '2024-04-04 01:30:42'),
(33, 6, 1, '', 36, 36, 2, '2024-04-04 01:30:42'),
(34, 8, 1, '', 36, 36, 2, '2024-04-04 01:30:52'),
(41, 1, 6457, '', 36, 232452, 1, '2024-04-05 11:48:10'),
(42, 1, 23, '', 36, 828, 1, '2024-04-05 11:48:15'),
(43, 1, 2, '', 36, 72, 1, '2024-04-05 11:52:28'),
(44, 23, 2, '', 36, 72, 1, '2024-04-05 12:00:42');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_list`
--

CREATE TABLE `supplier_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `cperson` text NOT NULL,
  `contact` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier_list`
--

INSERT INTO `supplier_list` (`id`, `name`, `address`, `cperson`, `contact`, `status`, `date_created`, `date_updated`) VALUES
(1, 'ELEGANT', 'Sample Supplier Address 101', 'Supplier Staff 101', '09123456789', 1, '2021-11-02 09:36:19', '2021-11-02 09:36:19');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Stock Management System - PHP'),
(6, 'short_name', 'SMS- PHP'),
(11, 'logo', 'uploads/logo-1635816671.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1635816671.png'),
(15, 'content', 'Array');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', NULL, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatar-1.png?v=1635556826', NULL, 1, '2021-01-20 14:02:37', '2021-10-30 09:20:26'),
(10, 'John', NULL, 'Smith', 'jsmith', '39ce7e2a8573b41ce73b5ba41617f8f7', 'uploads/avatar-10.png?v=1635920488', NULL, 2, '2021-11-03 14:21:28', '2021-11-03 14:21:28'),
(11, 'Claire', NULL, 'Blake', 'cblake', 'cd74fae0a3adf459f73bbf187607ccea', 'uploads/avatar-11.png?v=1635920566', NULL, 1, '2021-11-03 14:22:46', '2021-11-03 14:22:46');

-- --------------------------------------------------------

--
-- Table structure for table `user_meta`
--

CREATE TABLE `user_meta` (
  `user_id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `back_order_list`
--
ALTER TABLE `back_order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `po_id` (`po_id`),
  ADD KEY `receiving_id` (`receiving_id`);

--
-- Indexes for table `bo_items`
--
ALTER TABLE `bo_items`
  ADD KEY `item_id` (`item_id`),
  ADD KEY `bo_id` (`bo_id`);

--
-- Indexes for table `item_list`
--
ALTER TABLE `item_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `po_items`
--
ALTER TABLE `po_items`
  ADD KEY `po_id` (`po_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `purchase_order_list`
--
ALTER TABLE `purchase_order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `receiving_list`
--
ALTER TABLE `receiving_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_list`
--
ALTER TABLE `return_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `sales_list`
--
ALTER TABLE `sales_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `supplier_list`
--
ALTER TABLE `supplier_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_meta`
--
ALTER TABLE `user_meta`
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `back_order_list`
--
ALTER TABLE `back_order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item_list`
--
ALTER TABLE `item_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `purchase_order_list`
--
ALTER TABLE `purchase_order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `receiving_list`
--
ALTER TABLE `receiving_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `return_list`
--
ALTER TABLE `return_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sales_list`
--
ALTER TABLE `sales_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stock_list`
--
ALTER TABLE `stock_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `supplier_list`
--
ALTER TABLE `supplier_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `back_order_list`
--
ALTER TABLE `back_order_list`
  ADD CONSTRAINT `back_order_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `back_order_list_ibfk_2` FOREIGN KEY (`po_id`) REFERENCES `purchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `back_order_list_ibfk_3` FOREIGN KEY (`receiving_id`) REFERENCES `receiving_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bo_items`
--
ALTER TABLE `bo_items`
  ADD CONSTRAINT `bo_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bo_items_ibfk_2` FOREIGN KEY (`bo_id`) REFERENCES `back_order_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `item_list`
--
ALTER TABLE `item_list`
  ADD CONSTRAINT `item_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `po_items`
--
ALTER TABLE `po_items`
  ADD CONSTRAINT `po_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `po_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `purchase_order_list`
--
ALTER TABLE `purchase_order_list`
  ADD CONSTRAINT `purchase_order_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `return_list`
--
ALTER TABLE `return_list`
  ADD CONSTRAINT `return_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD CONSTRAINT `stock_list_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
