<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generate_report'])) {
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];

    // Assuming you have established a database connection named $conn

    $query = "SELECT s.id as sales_id, s.sales_code, s.client, s.amount, s.remarks, i.id AS item_id, i.name AS item_name, sl.quantity AS quantity_purchased, s.date_created, s.date_updated 
                FROM sales_list s 
                INNER JOIN stock_list sl ON FIND_IN_SET(sl.id, s.stock_ids)
                INNER JOIN item_list i ON sl.item_id = i.id
                WHERE s.date_created BETWEEN '$from_date' AND '$to_date'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $total_sales = 0;
        $total_items_sold = 0;
        $total_quantity_sold = 0;
        $item_sales = [];

        while ($row = $result->fetch_assoc()) {
            $total_sales += $row['amount'];
            $total_items_sold++;
            $total_quantity_sold += $row['quantity_purchased']; 

            if (!isset($item_sales[$row['item_id']])) {
                $item_sales[$row['item_id']] = 0;
            }
            $item_sales[$row['item_id']] += $row['quantity_purchased'];
        }

        asort($item_sales);
        $lowest_selling_product_id = key($item_sales);
        end($item_sales);
        $highest_selling_product_id = key($item_sales);

        $table = "<div class='card card-outline card-success card-danger'>";
        $table .= "<div class='card-header'>";
        $table .= "<h3 class='card-title'>Generated Sales Report</h3>";
        $table .= "</div>";
        $table .= "<div class='card-body'>";
        $table .= "<table class='table'>";
        $table .= "<thead>";
        $table .= "<tr>";
        $table .= "<th>Sales ID</th>"; // Changed here
        $table .= "<th>Sales Code</th>";
        $table .= "<th>Client</th>";
        $table .= "<th>Amount</th>";
        $table .= "<th>Remarks</th>";
        $table .= "<th>Item Name</th>";
        $table .= "<th>Quantity Purchased</th>";
        $table .= "<th>Date Created</th>";
        $table .= "<th>Date Updated</th>";
        $table .= "</tr>";
        $table .= "</thead>";
        $table .= "<tbody>";

        $result->data_seek(0);
        while ($row = $result->fetch_assoc()) {
            $table .= "<tr>";
            $table .= "<td>" . $row['item_id'] . "</td>"; // Using item ID as sales ID
            $table .= "<td>" . $row['sales_code'] . "</td>";
            $table .= "<td>" . $row['client'] . "</td>";
            $table .= "<td>" . $row['amount'] . "</td>";
            $table .= "<td>" . $row['remarks'] . "</td>";
            $table .= "<td>" . $row['item_name'] . "</td>";
            $table .= "<td>" . $row['quantity_purchased'] . "</td>";
            $table .= "<td>" . $row['date_created'] . "</td>";
            $table .= "<td>" . $row['date_updated'] . "</td>";
            $table .= "</tr>";
        }

        $table .= "</tbody>";
        $table .= "</table>";
        $table .= "<div style='margin-top: 20px;'>"; 
        $table .= "<p>Total Sales: $total_sales</p>";
        $table .= "<p>Total Items Sold: $total_items_sold</p>";
        $table .= "<p>Total Quantity Sold: $total_quantity_sold</p>"; 
        $table .= "<p>Highest-selling Product ID: $highest_selling_product_id</p>";
        $table .= "<p>Lowest-selling Product ID: $lowest_selling_product_id</p>";
        $table .= "</div>";
        $table .= "</div>";
        $table .= "</div>";

        $table .= "<button onclick='window.print()' class='btn btn-danger float-left mr-2'>Print</button>";
        $table .= "<a href='javascript:history.back()' class='btn btn-dark'>Back</a>";

        echo $table;
    } else {
        echo "<div class='alert alert-warning' role='alert'>No sales data found for the specified time frame.</div>";
        echo "<a href='javascript:history.back()' class='btn btn-dark'>Back</a>";
    }
} else {
?>

<div class="card card-outline card-danger">
    <div class="card-header">
        <h3 class="card-title">Generate Sales Report</h3>
    </div>
    <div class="card-body">
        <form id="report-form" method="POST">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="from_date">From Date</label>
                        <input type="date" class="form-control" id="from_date" name="from_date" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="to_date">To Date</label>
                        <input type="date" class="form-control" id="to_date" name="to_date" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>&nbsp;</label><br>
                        <button type="submit" class="btn btn-danger" name="generate_report">Generate Report</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
}
?>
