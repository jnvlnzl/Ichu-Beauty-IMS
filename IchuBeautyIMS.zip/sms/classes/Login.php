<?php
require_once '../config.php';

class Login {
    private $settings;

    public function __construct(){
        global $_settings;
        $this->settings = $_settings;
        ini_set('display_error', 1);
    }

    public function index(){
        echo "<h1>Welcome, Admin!</h1>";
    }

    public function login($username, $password){
        if($username === 'admin' && $password === 'admin123') {
            $this->settings->set_userdata('username', $username);
            $this->settings->set_userdata('login_type', 1); 
            return json_encode(array('status' => 'success'));
        } else {
            return json_encode(array('status' => 'incorrect'));
        }
    }

    public function logout(){
        if($this->settings->sess_des()){
            redirect('admin/login.php');
        }
    }
}

$action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
$auth = new Login();

switch ($action) {
    case 'login':
        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        echo $auth->login($username, $password);
        break;
    case 'logout':
        echo $auth->logout();
        break;
    default:
        echo $auth->index();
        break;
}
?>
